﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace пр_22_вар_7
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int[] mas;
        private void MassiveData_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            //Отчищаем textbox с результатом умножения
            rezultBox.Clear();
            //Определяем номер столбца
            int columnIndex = e.Column.DisplayIndex;
            //Заносим полученное значение в массив
            mas[columnIndex] = Convert.ToInt32(((TextBox)e.EditingElement).Text);
        }
        private void fillButton_Click(object sender, RoutedEventArgs e)
        {
            //Проверка поля на корректность введенных данных
            if (Int32.TryParse(columnCount.Text, out int count) && count > 0)
            {
                //задаем массиву размерность
                mas = new int[count];
                //Определяем диапазон чисел
                int minValue = 0, maxValue = 0;
                //если активна радиокнопка отрицательных значений
                if (otr.IsChecked.Value == true)
                {
                    minValue = -1000;
                    maxValue = 0;
                }
                //если активна радиокнопка положительных значений
                if (pol.IsChecked.Value == true)
                {
                    minValue = 0;
                    maxValue = 1000;
                }
                //Заполняем массив случайными числами в полученном диапазоне
                Random rnd = new Random();
                for (int i = 0; i < mas.Length; i++)
                {
                    mas[i] = rnd.Next(minValue, maxValue);
                }
                //Выводим массив на форму
                masData.ItemsSource = VisualArray.ToDataTable(mas).DefaultView;
                rezultBox.Clear();
            }
            else MessageBox.Show("Неверные данные!", "Ошибка", MessageBoxButton.OK);
        }
        private void Rezult_Click(object sender, RoutedEventArgs e)
        {
            if (mas == null || mas.Length == 0)
            {
                MessageBox.Show("Вы не создали массив, укажите количество колонок, диапазон чисел и нажмите кнопку \"Заполнить", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //Находим произведение всех элементов массива
            int rezult = mas[0];
            for (int i = 1; i < mas.Length; i++)
            {
                rezult -= mas[i];
            }
            //Выводим результат в textbox
            rezultBox.Text = rezult.ToString();
        }
        private void Rezult_Clear(object sender, RoutedEventArgs e)
        {
            rezultBox.Clear();
        }
        private void MassiveClear(object sender, RoutedEventArgs e)
        {
            rezultBox.Clear();
            //Заполняем массив нулями
            for (int i = 0; i < mas.Length; i++)
            {
                mas[i] = 0;
            }
            //Выводим массив на форму
            masData.ItemsSource = VisualArray.ToDataTable(mas).DefaultView;
        }
        private void Info_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Разработчик - Фио\nПрактическая работа №21. Вариант 7\n\nЧасть 1. Ввести n целых чисел(>0 или <0). Найти разность чисел. Результат вывести на экран.\n\nЧасть 2. Дана матрица размера M * N. Найти номера строки и столбца для элемента матрицы, наиболее близкого к среднему значению всех ее элементов.", "О программе", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        int[,] matr;
        private void CreareMatrix_Click(object sender, RoutedEventArgs e)
        {
            //Проверяем textbox
            if (Int32.TryParse(rowCount.Text, out int row) && Int32.TryParse(colCount.Text, out int column) && row > 0 && column > 0)
            {
                //Заполняем массив случайными числами
                matr = new int[row, column];
                Random rnd = new Random();
                for (int i = 0; i < row; i++)
                {
                    for (int j = 0; j < column; j++)
                    {
                        matr[i, j] = rnd.Next(50);
                    }
                }
                //Выводим массив на форму
                matrData.ItemsSource = VisualArray.ToDataTable(matr).DefaultView;
                rezult2.Clear();
            }
            else MessageBox.Show("Неверные данные", "Ошибка", MessageBoxButton.OK);
        }
        private void RezultMatrix_Click(object sender, RoutedEventArgs e)
        {
            if (matr != null && matr.Length != 0)
            {
                int sum = 0;
                for (int i = 0; i < matr.GetLength(0); i++)
                {
                    for (int j = 0; j < matr.GetLength(1); j++)
                    {
                        sum += matr[i, j];
                    }
                }
                int srArif = sum / matr.Length;
                int raznost = Math.Abs(srArif - matr[0, 0]);
                int iIndex = 0;
                int jIndex = 0;
                for (int i = 0; i < matr.GetLength(0); i++)
                {
                    for (int j = 0; j < matr.GetLength(1); j++)
                    {
                        if (raznost > Math.Abs(srArif - matr[i, j]))
                        {
                            raznost = Math.Abs(srArif - matr[i, j]);
                            iIndex = i;
                            jIndex = j;
                        }
                    }
                }
                rezult2.Text = $"Номер строки - {iIndex + 1}, номер столбца - {jIndex + 1}, сред. ариф - {srArif}";
            }
            else MessageBox.Show("Вы не создали матрицу, укажите размеры матрицы и нажмите кнопку \"Заполнить", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        private void MatrixClean_Click(object sender, RoutedEventArgs e)
        {
            if (matr != null && matr.Length != 0)
            {
                //Заполняем матрицу нулями
                for (int i = 0; i < matr.GetLength(0); i++)
                {
                    for (int j = 0; j < matr.GetLength(1); j++)
                    {
                        matr[i, j] = 0;
                    }
                }
                //Выводим массив на форму
                matrData.ItemsSource = VisualArray.ToDataTable(matr).DefaultView;
            }
            else MessageBox.Show("Вы не создали матрицу, укажите размеры матрицы и нажмите кнопку \"Заполнить", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        private void MatrixData_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            //Определяем номер столбца
            int columnIndex = e.Column.DisplayIndex;
            //Определяем номер строки
            int rowIndex = e.Row.GetIndex();
            //Заносим полученное значение в массив
            matr[rowIndex, columnIndex] = Convert.ToInt32(((TextBox)e.EditingElement).Text);
            rezult2.Clear();
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (matr == null && mas == null)//если матрицы пусты нет смысла что-то сохранять
            {
                MessageBox.Show("Таблицы пусты", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Все файлы (*.*) | *.* | Текстовые файлы | *.txt"; //фильтр форматов файлов
            save.DefaultExt = ".txt";//стандартный фильтр
            save.FilterIndex = 2;//изначальный фильтр
            save.Title = "Сохранение таблиц";
            if (save.ShowDialog() == true)
            {
                StreamWriter write = new StreamWriter(save.FileName); //открываем выбранный файл
                if (mas != null)
                {
                    write.WriteLine(mas.Length);//записываем размер массива
                    for (int i = 0; i < mas.Length; i++)
                    {
                        write.WriteLine(mas[i]);//записываем массив в файл 
                    }
                }
                else write.WriteLine(0);
                if (matr != null)
                {
                    write.WriteLine(matr.GetLength(0)); //записываем кол-во строк
                    write.WriteLine(matr.GetLength(1)); //записываем кол-во столбцов
                    for (int i = 0; i < matr.GetLength(0); i++)
                    {
                        for (int j = 0; j < matr.GetLength(1); j++)
                        {
                            write.WriteLine(matr[i, j]); //записываем матрицу в файл 
                        }
                    }
                }
                else
                {
                    write.WriteLine(0);
                }
                write.Close();//закрываем файл
            }
        }
        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Все файлы (*.*) | *.* | Текстовые файлы | *.txt"; //фильтр форматов файлов
            open.DefaultExt = ".txt";//стандартный фильтр
            open.FilterIndex = 2;//изначальный фильтр
            open.Title = "Открытие таблиц";
            if (open.ShowDialog() == true)
            {
                StreamReader read = new StreamReader(open.FileName); //открываем выбранный файл            
                if (Int32.TryParse(read.ReadLine(), out int lengthMas) && lengthMas > 0) //получаем длинну массива
                {
                    mas = new int[lengthMas];
                    for (int i = 0; i < lengthMas; i++)
                    {
                        mas[i] = Convert.ToInt32(read.ReadLine());//заполняем массив
                    }
                    masData.ItemsSource = VisualArray.ToDataTable(mas).DefaultView;//выводим массив на форму
                }
                if (Int32.TryParse(read.ReadLine(), out int rowMatr) && rowMatr > 0) //получаем кол-во строк матрицы
                {
                    int columnMatr = Convert.ToInt32(read.ReadLine()); //получаем кол-во столбцов матрицы
                    matr = new int[rowMatr, columnMatr];
                    for (int i = 0; i < rowMatr; i++)
                    {
                        for (int j = 0; j < columnMatr; j++)
                        {
                            matr[i, j] = Convert.ToInt32(read.ReadLine());//заполняем матрицу
                        }
                    }
                    matrData.ItemsSource = VisualArray.ToDataTable(matr).DefaultView;//выводим матрицу на форму
                }
            }

        }
    }
}